﻿using System;
using System.Drawing;

namespace lab1_obj_parser
{
    public class Rasterizer
    {
        private NewBitmap _canvas;

        public Rasterizer(NewBitmap canvas)
        {
            _canvas = canvas;
        }
        // Алгоритм Брезенхема
        public void DrawLine(int x0, int y0, int x1, int y1, Color color)
        {
            int dx = Math.Abs(x1 - x0);
            int dy = Math.Abs(y1 - y0);
            int sx = (x0 < x1) ? 1 : -1;
            int sy = (y0 < y1) ? 1 : -1;
            int err = dx - dy;

            int maxSteps = dx + dy + 1;
            int steps = 0;

            while (steps < maxSteps)
            {
                _canvas.SetPixel(x0, y0, color);   

                if (x0 == x1 && y0 == y1) break;

                int e2 = 2 * err;
                if (e2 > -dy)
                {
                    err -= dy;
                    x0 += sx;
                }
                if (e2 < dx)
                {
                    err += dx;
                    y0 += sy;
                }
                steps++;
            }
        }
        private void Swap(ref int a, ref int b)
        {
            int temp = a; 
            a = b; 
            b = temp;
        }

        public void DrawTriangle(int x1, int y1, int x2, int y2, int x3, int y3, Color color)
        {
            // 1. Сортировка вершин по Y (пузырьком)
            // Нам нужно, чтобы (x1, y1) была самой верхней точкой, а (x3, y3) - самой нижней
            if (y1 > y2) { Swap(ref x1, ref x2); Swap(ref y1, ref y2); }
            if (y1 > y3) { Swap(ref x1, ref x3); Swap(ref y1, ref y3); }
            if (y2 > y3) { Swap(ref x2, ref x3); Swap(ref y2, ref y3); }

            // Теперь y1 <= y2 <= y3

            // 2. Рисуем верхнюю половину треугольника (от y1 до y2)
            // Здесь высота части h = y2 - y1
            int totalHeight = y3 - y1;

            for (int i = 0; i < totalHeight; i++)
            {
                // Текущая сканирующая линия Y
                int y = y1 + i;

                if (y < 0 || y >= 1000) continue; // Хадкод высоты или передать _canvas.Height

                bool secondHalf = i > y2 - y1 || y2 == y1;
                int segmentHeight = secondHalf ? y3 - y2 : y2 - y1;

                if (segmentHeight == 0) 
                    segmentHeight = 1;

                // Вычисляем координаты X на сторонах треугольника

                // Сторона A (Длинная, от верха до низа): Интерполируем между (x1,y1) и (x3,y3)
                float alpha = (float)i / totalHeight;
                int ax = x1 + (int)((x3 - x1) * alpha);

                // Сторона B (Ломаная):
                // Если мы в верхней части, интерполируем между (x1,y1) и (x2,y2)
                // Если мы в нижней части, интерполируем между (x2,y2) и (x3,y3)
                float beta = (float)(i - (secondHalf ? y2 - y1 : 0)) / segmentHeight;
                int bx;

                if (!secondHalf)
                {
                    bx = x1 + (int)((x2 - x1) * beta);
                }
                else
                {
                    bx = x2 + (int)((x3 - x2) * beta);
                }

                // Упорядочиваем ax и bx, чтобы рисовать слева направо
                if (ax > bx) Swap(ref ax, ref bx);

                // Рисуем горизонтальную линию
                for (int x = ax; x <= bx; x++)
                {
                    _canvas.SetPixel(x, y, color);
                }
            }
        }

    }
}