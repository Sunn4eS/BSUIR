﻿using lab1_obj_parser;
using System;
using System.Drawing;

namespace lab1_obj_parser
{
    public class LinkerForRender
    {
        public int Width { get; set; }
        public int Height { get; set; }

        // Параметры трансформации модели (Model Matrix)
        public Vec4 ModelPosition { get; set; } = new Vec4(0, 0, 0);
        public Vec4 ModelRotation { get; set; } = new Vec4(0, 0, 0); // Углы Эйлера
        public Vec4 ModelScale { get; set; } = new Vec4(1, 1, 1);

        // Параметры камеры (View Matrix)
        public Vec4 CameraPosition { get; set; } = new Vec4(0, 0, 5);
        public Vec4 CameraTarget { get; set; } = new Vec4(0, 0, 0);
        public Vec4 CameraUp { get; set; } = new Vec4(0, 1, 0);

        public LinkerForRender(int width, int height)
        {
            Width = width;
            Height = height;
        }

        private Random _rnd = new Random();

        public void Render(Model model, Rasterizer rasterizer)
        {
            // Матрица Модели (Translate * Rotate * Scale)
           
            Matrix4x4 matScale = Matrix4x4.Scale(ModelScale.X, ModelScale.Y, ModelScale.Z);
            Matrix4x4 matRotX = Matrix4x4.RotateX(ModelRotation.X);
            Matrix4x4 matRotY = Matrix4x4.RotateY(ModelRotation.Y);
            Matrix4x4 matRotZ = Matrix4x4.RotateZ(ModelRotation.Z);
            Matrix4x4 matTrans = Matrix4x4.Translation(ModelPosition.X, ModelPosition.Y, ModelPosition.Z);

            Matrix4x4 modelMatrix = matTrans * matRotZ * matRotY * matRotX * matScale;
            
            Matrix4x4 viewMatrix = Matrix4x4.LookAt(CameraPosition, CameraTarget, CameraUp);

            // Матрица Проекции
            Matrix4x4 projectionMatrix = Matrix4x4.Perspective(Math.PI / 4, (double)Width / Height, 0.1, 100.0);

            // Матрица Viewport 
            Matrix4x4 viewportMatrix = Matrix4x4.Viewport(Width, Height);

            // MVP = Projection * View * Model
            Matrix4x4 mvpMatrix = projectionMatrix * viewMatrix * modelMatrix;

            // Отрисовка каждого полигона
            //foreach (var faceIndices in model.Faces)
            //{
            //    for (int i = 0; i < faceIndices.Length; i++)
            //    {
            //        int index1 = faceIndices[i];
            //        int index2 = faceIndices[(i + 1) % faceIndices.Length];

            //        Vec4 v1 = model.Vertices[index1];
            //        Vec4 v2 = model.Vertices[index2];

            //        v1 = ProcessVertex(v1, mvpMatrix, viewportMatrix);
            //        v2 = ProcessVertex(v2, mvpMatrix, viewportMatrix);

            //        rasterizer.DrawLine((int)v1.X, (int)v1.Y, (int)v2.X, (int)v2.Y, Color.Black);
            //    }
            //}

            foreach (var faceIndices in model.Faces)
            {
                int i0 = faceIndices[0];
                int i1 = faceIndices[1];
                int i2 = faceIndices[2];

                Vec4 v1 = model.Vertices[i0];
                Vec4 v2 = model.Vertices[i1];
                Vec4 v3 = model.Vertices[i2];

                Vec4 c1 = mvpMatrix * v1;
                Vec4 c2 = mvpMatrix * v2;
                Vec4 c3 = mvpMatrix * v3;

                //if (c1.W < 0.1 || c2.W < 0.1 || c3.W < 0.1) continue;

                // 2. Деление и Viewport
                Vec4 s1 = PerspectiveDivide(c1, viewportMatrix);
                Vec4 s2 = PerspectiveDivide(c2, viewportMatrix);
                Vec4 s3 = PerspectiveDivide(c3, viewportMatrix);

                // --- ЭТАП 1: РАСТЕРИЗАЦИЯ ТРЕУГОЛЬНИКА ---

                // Генерируем случайный цвет для каждого треугольника, 
                // чтобы проверить работу заливки (иначе всё сольется в пятно)
                Color debugColor = Color.FromArgb(
                    _rnd.Next(50, 255),
                    _rnd.Next(50, 255),
                    _rnd.Next(50, 255)
                );

                rasterizer.DrawTriangle(
                    (int)s1.X, (int)s1.Y,
                    (int)s2.X, (int)s2.Y,
                    (int)s3.X, (int)s3.Y,
                    debugColor
                );
            }
        }

        // Добавьте этот метод в класс RenderPipeline вместо старого ProcessVertex
        private Vec4 PerspectiveDivide(Vec4 vClip, Matrix4x4 viewport)
        {
            // В этот момент мы уже уверены, что W > 0.1 (благодаря проверке выше)

            // Нормализация (NDC)
            double invW = 1.0 / vClip.W;
            vClip.X *= invW;
            vClip.Y *= invW;
            vClip.Z *= invW;
            vClip.W = 1.0;

            // Viewport
            return viewport * vClip;
        }


        //private Vec4 ProcessVertex(Vec4 v, Matrix4x4 mvp, Matrix4x4 viewport)
        //{
        //    Vec4 vClip = mvp * v;

        //    if (vClip.W != 0) 
        //    {
        //        vClip.X /= vClip.W;
        //        vClip.Y /= vClip.W;
        //        vClip.Z /= vClip.W;
        //    }
        //    vClip.W = 1.0;
        //    Vec4 vScreen = viewport * vClip;

        //    return vScreen;
        //}
    }
}